export default {
  input: 'src/all.js', 
  output: [
    { file: 'dist/splitting.js', name: 'Splitting', format: 'umd' }
  ]
}